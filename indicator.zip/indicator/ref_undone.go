// All rights reserved. This is part of West Securities ltd. proprietary source code.
// No part of this file may be reproduced or transmitted in any form or by any means,
// electronic or mechanical, including photocopying, recording, or by any information
// storage and retrieval system, without the prior written permission of West Securities ltd.

// author:  Wonderstone (Digital Office Product Department #2)
// revisor:

package indicator

// EMA is the moving average indicator
type Ref struct {
	ParSlice   []int
	tmp, lv, w float64
	// info fields for indicator calculation
	InfoSlice []string
}

// NewMA returns a new MA indicator
func NewRef(ParSlice []int, infoslice []string) *EMA {
	return &EMA{
		ParSlice:  ParSlice,
		InfoSlice: infoslice,
		w:         2.0 / (float64(ParSlice[0]) + 1.0),
	}
}

// LoadData loads 1 tick info datas into the indicator
func (r *Ref) LoadData(data map[string]float64) {
	r.tmp = data[r.InfoSlice[0]]
}

// Eval evaluates the indicator
func (r *Ref) Eval() float64 {
	res := r.w*r.tmp + (1-r.w)*r.lv
	r.lv = res
	return res
}
