package indicator 

type BOP struct {
	closing,opening,high,low float64
	

	// info fields for indicator calculation
	InfoSlice []string  //[closing,opening,high,low]
}
func NewBOP(infoslice []string) *BOP {
	return &BOP{
		InfoSlice: infoslice,
	}
}
func (bop *BOP) LoadData(data map[string]float64) {
	bop.closing=data[bop.InfoSlice[0]]
	bop.opening=data[bop.InfoSlice[1]]
	bop.high=data[bop.InfoSlice[2]]
	bop.low=data[bop.InfoSlice[3]]
}
func (bop *BOP) Eval() float64 {
	result := (bop.closing-bop.opening)/(bop.high- bop.low)
	return result
}

